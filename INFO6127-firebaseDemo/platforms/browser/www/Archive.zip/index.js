/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);

        // TODO: Remove this - testing only
        // this will simulate the deviceready callback for us since we are testing without any plugins in the browser
        app.receivedEvent('deviceReady');

        firebase.auth().onAuthStateChanged(function(user) {

            if (user) {
                console.log('User is authenticated');
                console.log(JSON.stringify(user));
                appAuth.setUser(user.uid, user.email);

                readExamples.loadCurrentUser();
                readExamples.watchCurrentUser(user.uid);
            } else {
                // user logged out
                console.log('User logged out');
                appAuth.setUser('', '');
            }
        });
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        app.receivedEvent('deviceready');
    },
    // Update DOM on a Received Event
    receivedEvent: function(id) {

    },
    loginUser: function() {
        var email = document.getElementById('email').value;
        var password = document.getElementById('password').value;

        appAuth.loginUser(email, password);
    },
};

var appAuth = {
    loginUser: function(email, password) {
        // clear user
        app.setUser('', '');

        console.log(email);
        console.log(password);

        if (!email || !password) {
            displayAuthError('Invalid email/password');
            return;
        }

        firebase.auth().signInWithEmailAndPassword(email, password).catch(function(error) {
            // Handle Errors here.
            var errorCode = error.code;
            var errorMessage = error.message;

            console.log('Received Error: ' + errorCode);
            displayAuthError('Error authenticating user: ' + error);
        });

        function displayAuthError(error) {
            console.error(error);
            document.getElementById('authError').innerText = error;
        }
    },
    setUser: function(id, email) {
        console.log('set user: ' + id);

        document.getElementById('authUserId').value = id;
        document.getElementById('authEmail').value = email;
    },
    getCurrentUser: function() {
        return firebase.auth().currentUser.uid;
    }
};

var readExamples = {
    loadCurrentUser: function() {
        var userId = firebase.auth().currentUser.uid;
        console.log('User is ' + userId);

        firebase.database().ref('users/' + userId).once('value', function(snapshot) {

            if (snapshot.exists()) {

                console.log(JSON.stringify(snapshot.val()));

                var keyAkaUserId = snapshot.key;
                var firstName = snapshot.val().firstName;
                var lastName = snapshot.val().lastName;

                document.getElementById('userIdOnce').value = keyAkaUserId;
                document.getElementById('firstNameOnce').value = firstName;
                document.getElementById('lastNameOnce').value = lastName;

            } else {
                console.warn('User does not exist');
            }

        });
    },
    watchCurrentUser: function() {

        var userId = appAuth.getCurrentUser();

        firebase.database().ref('users/' + userId).on('value', function(snapshot) {

            if (snapshot.exists()) {

                console.log(JSON.stringify(snapshot.val()));

                var keyAkaUserId = snapshot.key;
                var firstName = snapshot.val().firstName;
                var lastName = snapshot.val().lastName;

                document.getElementById('userIdOn').value = keyAkaUserId;
                document.getElementById('firstNameOn').value = firstName;
                document.getElementById('lastNameOn').value = lastName;

            } else {
                console.warn('User does not exist');
            }

        });

    },
};

var writeExamples = {

    setUserName: function() {
        // clear previous message
        writeExamples.displayStatusMessage('');

        var firstName = document.getElementById('firstNameSet').value;
        var lastName = document.getElementById('lastNameSet').value;

        // TODO: validation

        // create an object
        var user = {
            firstName: firstName,
            lastName: lastName
        };

        var userId = appAuth.getCurrentUser();

        firebase.database().ref('users').child(userId).set(user, function(error) {

            var message = '';

            if (error) {
                console.error(error);
                message = 'Error: ' + error;
            } else {
                message = 'Successfully updated user';
            }

            writeExamples.displayStatusMessage(message);
        });
    },
    updateFavouriteColor: function() {

        // clear previous message
        writeExamples.displayStatusMessage('');

        var color = document.getElementById('favouriteColor').value;

        var data = {
            color: color
        };

        firebase.database().ref('users').child(appAuth.getCurrentUser()).child('favourites').update(data, function(error) {

            var message = '';

            if (error) {
                console.error(error);
                message = 'Error: ' + error;
            } else {
                message = 'Successfully updated favourite color';
            }

            writeExamples.displayStatusMessage(message);

        });
    },
    updateFavouriteSong: function() {

        // clear previous message
        writeExamples.displayStatusMessage('');

        var song = document.getElementById('favouriteSong').value;

        if (!song) {
            writeExamples.deleteFavouriteSong();
        } else {
            var data = {
                song: song
            };

            firebase.database().ref('users').child(appAuth.getCurrentUser()).child('favourites').update(data, function (error) {

                var message = '';

                if (error) {
                    console.error(error);
                    message = 'Error: ' + error;
                } else {
                    message = 'Successfully updated favourite song';
                }

                writeExamples.displayStatusMessage(message);

            });
        }
    },
    deleteFavouriteSong: function() {

        firebase.database().ref('users').child(appAuth.getCurrentUser()).child('favourites/song').remove(function(error) {
            var message = '';

            if (error) {
                console.error(error);
                message = 'Error: ' + error;
            } else {
                message = 'Successfully deleted favourite song';
            }

            writeExamples.displayStatusMessage(message);
        });

    },
    displayStatusMessage: function(message) {
        document.getElementById('writeStatusMessage').innerText = message;
    }

};


